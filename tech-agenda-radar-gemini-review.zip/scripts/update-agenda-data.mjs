import { mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const rootDir = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const jsOutputPath = resolve(rootDir, "agenda-data.js");
const jsonOutputPath = resolve(rootDir, "agenda-data.json");
const historyDir = resolve(rootDir, "history");
const KST_OFFSET_MS = 9 * 60 * 60 * 1000;
const colors = ["#0f8f82", "#3563c8", "#d68419", "#c54b40", "#3f8f4f", "#7a5a26"];

const sources = [
  {
    name: "AI Times",
    region: "KR",
    kind: "RSS",
    url: "https://www.aitimes.com/",
    feed: "https://cdn.aitimes.com/rss/gn_rss_allArticle.xml"
  },
  {
    name: "DigitalToday AI",
    region: "KR",
    kind: "HTML",
    url: "https://www.digitaltoday.co.kr/news/articleList.html?sc_section_code=S1N10&view_type=sm",
    mode: "html"
  },
  {
    name: "Bloter IT",
    region: "KR",
    kind: "HTML",
    url: "https://www.bloter.net/news/articleList.html?sc_section_code=S1N4&view_type=sm",
    mode: "html"
  },
  {
    name: "ZDNet Korea AI",
    region: "KR",
    kind: "HTML",
    url: "https://zdnet.co.kr/search/?kwd=AI",
    mode: "html"
  },
  {
    name: "Naver IT",
    region: "KR",
    kind: "Portal",
    url: "https://news.naver.com/section/105"
  },
  {
    name: "Daum Digital",
    region: "KR",
    kind: "Portal",
    url: "https://news.daum.net/digital"
  },
  {
    name: "The Verge AI",
    region: "Global",
    kind: "RSS",
    url: "https://www.theverge.com/ai-artificial-intelligence",
    feed: "https://www.theverge.com/rss/ai-artificial-intelligence/index.xml"
  },
  {
    name: "TechCrunch AI",
    region: "Global",
    kind: "RSS",
    url: "https://techcrunch.com/category/artificial-intelligence/",
    feed: "https://techcrunch.com/category/artificial-intelligence/feed/"
  },
  {
    name: "OpenAI News",
    region: "Global",
    kind: "RSS",
    url: "https://openai.com/news/",
    feed: "https://openai.com/news/rss.xml"
  },
  {
    name: "Google AI Blog",
    region: "Global",
    kind: "RSS",
    url: "https://blog.google/technology/ai/",
    feed: "https://blog.google/innovation-and-ai/technology/ai/rss/"
  },
  {
    name: "MIT Technology Review",
    region: "Global",
    kind: "RSS",
    url: "https://www.technologyreview.com/",
    feed: "https://www.technologyreview.com/feed/"
  },
  {
    name: "WIRED AI",
    region: "Global",
    kind: "RSS",
    url: "https://www.wired.com/tag/artificial-intelligence/",
    feed: "https://www.wired.com/feed/tag/ai/latest/rss"
  },
  {
    name: "VentureBeat AI",
    region: "Global",
    kind: "RSS",
    url: "https://venturebeat.com/category/ai/",
    feed: "https://venturebeat.com/category/ai/feed/"
  },
  {
    name: "Hacker News",
    region: "Global",
    kind: "RSS",
    url: "https://news.ycombinator.com/",
    feed: "https://news.ycombinator.com/rss"
  }
];

const agendaTerms = [
  {
    id: "agent",
    label: "Agent",
    aliases: ["agent", "agents", "autonomous", "operator", "workflow", "tool use", "computer use"],
    color: "#0f8f82",
    title: "자율형 AI Agent가 업무 실행과 보안 통제의 핵심 의제로 부상",
    summary: "에이전트가 조회를 넘어 실행, 승인, 감사 로그가 필요한 업무 레이어로 이동하고 있습니다.",
    description: "툴 실행, 장시간 작업, 승인 게이트가 함께 언급됩니다.",
    brief: {
      background: "AI Agent가 이메일, 코드, 브라우저, 업무 도구를 직접 다루기 시작하면서 실행 경계가 제품 설계의 중심이 됐습니다.",
      reaction: "플랫폼 기업은 SDK와 런타임을 확장하고, 보안 업계는 샌드박스와 감사 로그를 기본 요구사항으로 제안합니다.",
      implication: "Agent 제품 경쟁은 자동화 범위뿐 아니라 권한 위임, 실패 복구, 승인 UX의 완성도로 갈립니다."
    }
  },
  {
    id: "mcp",
    label: "MCP",
    aliases: ["mcp", "model context protocol", "server", "connector", "integration", "tools"],
    color: "#3563c8",
    title: "MCP와 외부 도구 연결 표준이 AI 앱 생태계 확장의 관문으로 부상",
    summary: "모델과 사내 시스템, 개발 도구, 데이터 소스를 안전하게 연결하는 표준화 흐름이 강해지고 있습니다.",
    description: "외부 시스템 연결 표준으로 빠르게 제품 메시지화되고 있습니다.",
    brief: {
      background: "AI 앱이 단일 챗봇을 넘어 실제 업무 시스템과 연결되면서 표준화된 컨텍스트·툴 프로토콜 수요가 커졌습니다.",
      reaction: "개발자 커뮤니티는 서버 템플릿과 권한 패턴을 빠르게 실험하고, 기업은 내부 데이터 연결의 통제 지점을 검토합니다.",
      implication: "엔터프라이즈 AI 도입은 모델 성능만큼 연결 가능한 시스템 범위와 권한 관리 체계에 좌우됩니다."
    }
  },
  {
    id: "on-device",
    label: "On-Device",
    aliases: ["on-device", "on device", "edge ai", "npu", "local model", "device", "privacy"],
    color: "#d68419",
    title: "온디바이스 AI 경쟁이 NPU, 개인정보, 지연시간 중심으로 재편",
    summary: "모바일, PC, 브라우저 업체가 로컬 추론과 개인정보 보호 메시지를 전면에 세우고 있습니다.",
    description: "모바일, PC, 브라우저에서 로컬 추론 메시지가 강화됩니다.",
    brief: {
      background: "클라우드 추론 비용과 개인정보 규제가 맞물리며 일부 AI 기능을 기기 내부에서 처리하려는 압력이 커졌습니다.",
      reaction: "디바이스 업체는 NPU 성능, 지연시간, 배터리 효율을 묶어 차별화하고 개발자에게 로컬 API를 제공합니다.",
      implication: "서비스 사업자는 클라우드, 엣지, 로컬 모델을 상황별로 라우팅하는 제품 구조를 준비해야 합니다."
    }
  },
  {
    id: "sovereign",
    label: "Sovereign AI",
    aliases: ["sovereign", "national ai", "local cloud", "data sovereignty", "government", "public sector"],
    color: "#3f8f4f",
    title: "Sovereign AI와 로컬 클라우드 연합 전략이 공공·산업 AI 의제로 확대",
    summary: "정부, 통신사, 클라우드 사업자가 데이터 주권과 자체 모델 확보를 같은 전략으로 묶고 있습니다.",
    description: "정부, 통신, 클라우드가 로컬 데이터 주권을 사업화합니다.",
    brief: {
      background: "AI 인프라가 산업 경쟁력과 안보 이슈로 해석되면서 데이터와 컴퓨트를 국내 통제권 안에 두려는 요구가 커졌습니다.",
      reaction: "클라우드 사업자는 현지 리전과 파트너십을 늘리고, 로컬 기업은 산업별 특화 모델과 공공 조달 채널을 노립니다.",
      implication: "글로벌 AI 기업은 지역별 규제, 데이터 거버넌스, 로컬 파트너 번들 전략을 정교화해야 합니다."
    }
  },
  {
    id: "evalops",
    label: "EvalOps",
    aliases: ["eval", "evaluation", "benchmark", "monitoring", "guardrail", "safety", "red team"],
    color: "#c54b40",
    title: "AI 평가와 운영 모니터링이 모델 출시 이후의 핵심 통제면으로 이동",
    summary: "프롬프트 변경, 모델 교체, 툴 추가에 따른 품질 회귀를 감지하려는 수요가 커지고 있습니다.",
    description: "모델 도입 이후의 품질 추적과 회귀 테스트가 중요해집니다.",
    brief: {
      background: "AI 기능이 프로덕션 워크플로에 들어가며 작은 변경도 품질과 규정 준수 리스크로 이어지게 됐습니다.",
      reaction: "플랫폼과 스타트업은 평가 데이터셋, 추적, 실패 재현 기능을 LLMOps의 다음 계층으로 포지셔닝합니다.",
      implication: "AI 제품팀은 출시 전 데모보다 운영 중 회귀 감지와 부서별 품질 기준 관리 능력을 먼저 설계해야 합니다."
    }
  },
  {
    id: "ai-code",
    label: "AI Code",
    aliases: ["code", "coding", "developer", "github", "ide", "pull request", "software engineering"],
    color: "#7a5a26",
    title: "AI 코딩 도구가 IDE 보조를 넘어 저장소 운영과 배포 검증으로 확장",
    summary: "코드 생성보다 이슈 분석, 테스트 수정, PR 리뷰 자동화가 새 관심사로 이동하고 있습니다.",
    description: "코드 생성에서 저장소 운영과 검증 자동화로 관심이 이동합니다.",
    brief: {
      background: "개발자가 생성형 코딩에 익숙해지면서 병목이 코드 작성에서 검증, 리뷰, 배포 신뢰성으로 이동했습니다.",
      reaction: "툴 업체들은 터미널, GitHub, CI를 연결한 장시간 작업 에이전트를 내세우며 팀 단위 생산성 지표를 강조합니다.",
      implication: "기업 도입 판단은 라인 수 증가보다 실패 복구, 테스트 통과율, 보안 리뷰 누락 감소 같은 운영 지표로 옮겨갑니다."
    }
  }
];

const companies = [
  {
    id: "openai",
    name: "OpenAI",
    sector: "Model Platform",
    color: "#3563c8",
    short: "OA",
    focus: "에이전트 플랫폼과 멀티모달",
    terms: ["agent", "evalops", "ai-code", "mcp"],
    agendas: [
      {
        label: "Agent Runtime 표준화",
        term: "agent",
        description: "SDK, 툴 호출, 상태 관리를 묶어 에이전트 앱의 기본 실행 레이어를 장악하려는 흐름입니다.",
        heat: ["Runtime", "Tool Call", "Trace", "Handoff"]
      },
      {
        label: "평가 자동화 내재화",
        term: "evalops",
        description: "모델 교체와 프롬프트 변경 전후 품질 회귀를 플랫폼 안에서 검증하게 만드는 전략입니다.",
        heat: ["Regression", "Eval", "Guardrail", "Trace"]
      },
      {
        label: "개발 워크플로 장악",
        term: "ai-code",
        description: "코드 생성보다 이슈 분석, 테스트 수정, 리뷰까지 이어지는 저장소 운영면으로 확장하고 있습니다.",
        heat: ["Repo Ops", "PR Review", "CI Fix", "IDE"]
      },
      {
        label: "외부 툴 연결성 확보",
        term: "mcp",
        description: "타사 업무 시스템과 데이터 소스를 모델 경험 안으로 끌어오는 연결 표준 경쟁에 대응합니다.",
        heat: ["Connector", "Tool", "Context", "API"]
      }
    ]
  },
  {
    id: "anthropic",
    name: "Anthropic",
    sector: "Model Provider",
    color: "#0f8f82",
    short: "AN",
    focus: "MCP와 에이전트 개발면",
    terms: ["mcp", "agent", "ai-code", "evalops"],
    agendas: [
      {
        label: "MCP 생태계 선점",
        term: "mcp",
        description: "Claude가 업무 시스템과 연결되는 기본 통로를 MCP 서버와 커넥터 생태계로 넓히고 있습니다.",
        heat: ["MCP Server", "Connector", "Tool Use", "Permission"]
      },
      {
        label: "Claude Code 운영화",
        term: "ai-code",
        description: "IDE 보조를 넘어 터미널, 저장소, 테스트 수정까지 맡는 개발 운영 도구로 포지셔닝합니다.",
        heat: ["Claude Code", "Terminal", "Repo", "Test"]
      },
      {
        label: "권한 있는 Tool Use",
        term: "agent",
        description: "에이전트가 실제 업무를 실행할 때 승인, 권한 범위, 감사 로그를 제품 차별점으로 밀고 있습니다.",
        heat: ["Approval", "Audit", "Desktop", "Agent"]
      },
      {
        label: "안전성 평가 메시지",
        term: "evalops",
        description: "기업 도입의 불안을 줄이기 위해 모델 성능보다 실패 경계와 평가 체계를 함께 강조합니다.",
        heat: ["Safety Eval", "Red Team", "Policy", "Logs"]
      }
    ]
  },
  {
    id: "google",
    name: "Google",
    sector: "Cloud & Search",
    color: "#d68419",
    short: "GO",
    focus: "검색 재구성과 온디바이스",
    terms: ["on-device", "agent", "evalops", "sovereign"],
    agendas: [
      {
        label: "검색 수익모델 재설계",
        term: "agent",
        description: "AI 답변, 쇼핑, 광고가 한 화면에 섞이면서 검색 UX와 수익 배분이 동시에 흔들리고 있습니다.",
        heat: ["AI Search", "Ads", "Shopping", "Overview"]
      },
      {
        label: "Gemini 온디바이스화",
        term: "on-device",
        description: "Android와 Chrome 안에서 지연시간, 프라이버시, 로컬 개인화를 묶어 차별화하려는 흐름입니다.",
        heat: ["Gemini Nano", "Android", "Chrome", "NPU"]
      },
      {
        label: "TPU 원가 우위 방어",
        term: "evalops",
        description: "모델 경쟁을 클라우드 인프라 비용과 TPU 스택 락인으로 연결해 장기 원가 경쟁력을 지키려 합니다.",
        heat: ["TPU", "Vertex", "Cost", "Cloud"]
      },
      {
        label: "지역 AI 클라우드 패키징",
        term: "sovereign",
        description: "각국 데이터 주권 요구에 맞춰 클라우드 리전, 파트너, 모델 제공 방식을 현지화합니다.",
        heat: ["Region", "Gov", "Local Cloud", "Data"]
      }
    ]
  },
  {
    id: "naver",
    name: "Naver",
    sector: "Korea Platform",
    color: "#3f8f4f",
    short: "NV",
    focus: "소버린 AI와 검색 커머스",
    terms: ["sovereign", "on-device", "agent", "evalops"],
    agendas: [
      {
        label: "소버린 AI 영업 확대",
        term: "sovereign",
        description: "공공, 금융, 통신 고객에게 국내 데이터와 로컬 클라우드를 묶은 AI 인프라 패키지를 제안합니다.",
        heat: ["Public", "Finance", "Local Data", "Cloud"]
      },
      {
        label: "한국어 데이터 해자",
        term: "evalops",
        description: "범용 모델 경쟁보다 한국어, 검색 로그, 커머스 문맥의 정밀도를 차별화 포인트로 삼습니다.",
        heat: ["Korean Data", "Search Log", "Commerce", "Quality"]
      },
      {
        label: "검색 커머스 AI 전환",
        term: "agent",
        description: "검색, 쇼핑, 광고 추천을 생성형 응답 안에서 재배치해 플랫폼 체류와 거래 전환을 노립니다.",
        heat: ["Search", "Shopping", "Ads", "Creator"]
      },
      {
        label: "온디바이스 협력 가능성",
        term: "on-device",
        description: "모바일, 브라우저, 차량 등 한국어 개인화가 필요한 접점에서 로컬 추론 파트너십 여지가 있습니다.",
        heat: ["Mobile", "Browser", "Vehicle", "Personalization"]
      }
    ]
  },
  {
    id: "microsoft",
    name: "Microsoft",
    sector: "Enterprise Stack",
    color: "#c54b40",
    short: "MS",
    focus: "Copilot 운영면과 보안",
    terms: ["agent", "evalops", "ai-code", "mcp"],
    agendas: [
      {
        label: "Copilot 업무 레이어화",
        term: "agent",
        description: "Office, Teams, Windows의 반복 업무를 Copilot 액션으로 묶어 기업 기본 업무면을 넓힙니다.",
        heat: ["Office", "Teams", "Workflow", "Agent"]
      },
      {
        label: "Graph Grounding 강화",
        term: "mcp",
        description: "메일, 문서, 일정, 권한 정보를 Graph로 묶어 기업 내부 문맥을 모델 응답의 핵심 자산으로 만듭니다.",
        heat: ["Graph", "Identity", "Context", "Permission"]
      },
      {
        label: "보안 Copilot 확장",
        term: "evalops",
        description: "SOC, Defender, 감사 로그를 결합해 에이전트 도입에서 가장 먼저 예산이 붙는 보안 영역을 공략합니다.",
        heat: ["SOC", "Defender", "Audit", "Policy"]
      },
      {
        label: "개발자 플랫폼 방어",
        term: "ai-code",
        description: "GitHub와 Azure DevOps를 통해 코드 작성 이후 리뷰, 테스트, 배포 검증까지 묶어두려 합니다.",
        heat: ["GitHub", "Azure DevOps", "Review", "CI"]
      }
    ]
  }
];

function decodeXml(value = "") {
  return value
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tag(block, name) {
  const match = block.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`, "i"));
  return match ? decodeXml(match[1]) : "";
}

function parseFeed(xml, sourceName) {
  const blocks = [...xml.matchAll(/<item[\s\S]*?<\/item>/gi)].map((match) => match[0]);
  const entries = blocks.length ? blocks : [...xml.matchAll(/<entry[\s\S]*?<\/entry>/gi)].map((match) => match[0]);

  return entries
    .map((block) => {
      const rawLink = tag(block, "link");
      const hrefMatch = block.match(/<link[^>]+href="([^"]+)"/i);
      const published = tag(block, "pubDate") || tag(block, "updated") || tag(block, "published");
      const publishedAt = published ? new Date(published) : new Date();
      return {
        source: sourceName,
        title: tag(block, "title"),
        summary: tag(block, "description") || tag(block, "summary") || tag(block, "content:encoded"),
        link: hrefMatch ? hrefMatch[1] : rawLink,
        publishedAt: Number.isNaN(publishedAt.getTime()) ? new Date() : publishedAt
      };
    })
    .filter((item) => item.title);
}

function absoluteUrl(url, baseUrl) {
  try {
    return new URL(url, baseUrl).toString();
  } catch {
    return "";
  }
}

function cleanTitle(value) {
  const cleaned = decodeXml(value)
    .replace(/^\[[^\]]+\]\s*/g, "")
    .replace(/^[가-힣]{2,4}\s?기자\s*/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (cleaned.length <= 96) return cleaned;
  const sentenceEnd = cleaned.slice(0, 120).search(/[.!?。]|다\./);
  if (sentenceEnd > 28 && sentenceEnd < 96) return cleaned.slice(0, sentenceEnd + 1);
  return `${cleaned.slice(0, 92).trim()}...`;
}

function parseHtmlLinks(html, source) {
  const anchors = [...html.matchAll(/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)];
  return anchors
    .map((match) => {
      const link = absoluteUrl(decodeXml(match[1]), source.url);
      const title = cleanTitle(match[2]);
      return {
        source: source.name,
        title,
        summary: title,
        link,
        publishedAt: new Date()
      };
    })
    .filter((item) => item.link && item.title.length >= 12)
    .filter((item) => {
      const haystack = `${item.title} ${item.link}`.toLowerCase();
      return /ai|인공지능|생성형|챗gpt|openai|anthropic|google|naver|agent|mcp|llm|클라우드|반도체|보안|로봇|데이터/.test(haystack);
    })
    .slice(0, 30);
}

async function fetchSource(source) {
  if (!source.feed && source.mode !== "html") return [];
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(source.feed || source.url, {
      headers: { "user-agent": "TechAgendaRadar/1.0" },
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
    const body = await response.text();
    return source.mode === "html" ? parseHtmlLinks(body, source) : parseFeed(body, source.name);
  } catch (error) {
    console.warn(`[warn] ${source.name}: ${error.message}`);
    return [];
  } finally {
    clearTimeout(timeout);
  }
}

function uniqByTitle(items) {
  const seen = new Set();
  return items.filter((item) => {
    const key = item.title.toLowerCase().replace(/[^a-z0-9가-힣]/g, "").slice(0, 90);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function scoreArticle(article, term) {
  const title = article.title.toLowerCase();
  const body = `${article.title} ${article.summary}`.toLowerCase();
  return term.aliases.reduce((score, alias) => {
    const lowered = alias.toLowerCase();
    if (title.includes(lowered)) return score + 3;
    if (body.includes(lowered)) return score + 1;
    return score;
  }, 0);
}

function scoreTerms(articles) {
  return agendaTerms
    .map((term) => {
      const matches = articles
        .map((article) => ({ article, score: scoreArticle(article, term) }))
        .filter((match) => match.score > 0)
        .sort((a, b) => b.score - a.score || b.article.publishedAt - a.article.publishedAt);

      const score = matches.reduce((sum, match) => sum + match.score, 0);
      const sourceCount = new Set(matches.map((match) => match.article.source)).size;
      return { ...term, matches, score, sourceCount };
    })
    .sort((a, b) => b.score - a.score || b.sourceCount - a.sourceCount);
}

function kstParts(date) {
  const shifted = new Date(date.getTime() + KST_OFFSET_MS);
  return {
    year: shifted.getUTCFullYear(),
    month: String(shifted.getUTCMonth() + 1).padStart(2, "0"),
    day: String(shifted.getUTCDate()).padStart(2, "0"),
    hour: String(shifted.getUTCHours()).padStart(2, "0"),
    minute: String(shifted.getUTCMinutes()).padStart(2, "0"),
    weekday: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][shifted.getUTCDay()]
  };
}

function formatKst(date) {
  const part = kstParts(date);
  return `${part.year}.${part.month}.${part.day} ${part.hour}:${part.minute}`;
}

function formatKstDate(date) {
  const part = kstParts(date);
  return `${part.year}.${part.month}.${part.day} ${part.weekday}`;
}

function formatKstKey(date) {
  const part = kstParts(date);
  return `${part.year}-${part.month}-${part.day}`;
}

function nextKstMorning(date) {
  const shifted = new Date(date.getTime() + KST_OFFSET_MS);
  const next = new Date(Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate(), 8, 0, 0));
  if (shifted.getUTCHours() >= 8) next.setUTCDate(next.getUTCDate() + 1);
  return new Date(next.getTime() - KST_OFFSET_MS);
}

function widthPercent(value, max) {
  const width = Math.max(24, Math.round((value / Math.max(max, 1)) * 100));
  return `${width}%`;
}

function hashtagsForTerm(term, matches) {
  const companyTags = ["OpenAI", "Anthropic", "Google", "Naver", "Microsoft", "NVIDIA", "Notion", "Meta"]
    .filter((name) => matches.some(({ article }) => `${article.title} ${article.summary}`.toLowerCase().includes(name.toLowerCase())))
    .slice(0, 2);
  const aliasTags = term.aliases
    .filter((alias) => alias.length <= 18)
    .map((alias) => alias.replace(/\s+/g, ""))
    .slice(0, 3);
  return [...new Set([term.label.replace(/\s+/g, ""), ...companyTags, ...aliasTags])]
    .slice(0, 5)
    .map((tag) => `#${tag}`);
}

function relatedCompaniesForTerm(term, matches) {
  const knownCompanies = [
    ...companies.map((company) => company.name),
    "NVIDIA",
    "Meta",
    "Apple",
    "Amazon",
    "Samsung",
    "Kakao",
    "SK Telecom"
  ];
  const haystack = matches
    .slice(0, 12)
    .map(({ article }) => `${article.title} ${article.summary}`)
    .join(" ")
    .toLowerCase();
  const mentioned = knownCompanies.filter((name) => haystack.includes(name.toLowerCase()));
  const strategic = companies.filter((company) => company.terms.includes(term.id)).map((company) => company.name);
  return [...new Set([...mentioned, ...strategic])].slice(0, 5);
}

function sourcesForTerm(term, matches) {
  const articleSources = matches
    .slice(0, 6)
    .map(({ article }) => ({
      title: article.title,
      url: article.link,
      media: article.source
    }))
    .filter((source) => source.title && source.url);

  if (articleSources.length) return articleSources;

  return sources.slice(0, 3).map((source) => ({
    title: `${term.label} 레이더 수집 대기`,
    url: source.url,
    media: source.name
  }));
}

function sourcesForCompanyAgenda(company, agenda, termSignal) {
  const matches = termSignal.matches || [];
  const productNeedles = {
    openai: ["OpenAI", "ChatGPT", "Codex", "Agents SDK", "Responses API", "Sora"],
    anthropic: ["Anthropic", "Claude", "Claude Code", "MCP"],
    google: ["Google", "Gemini", "AI Overviews", "Android", "Chrome", "TPU", "Vertex"],
    naver: ["Naver", "네이버", "HyperCLOVA", "CLOVA", "클로바"],
    microsoft: ["Microsoft", "Copilot", "Graph", "Office", "Teams", "Defender", "GitHub", "Azure", "Windows"]
  };
  const needles = [company.name, company.id, ...(productNeedles[company.id] || [])]
    .map((value) => String(value).toLowerCase())
    .filter((value) => value.length > 2);
  const directMatches = matches.filter(({ article }) => {
    const haystack = `${article.title} ${article.summary} ${article.source}`.toLowerCase();
    return needles.some((needle) => haystack.includes(needle));
  });
  const selected = (directMatches.length ? directMatches : matches).slice(0, 3);

  return selected.map(({ article }) => ({
    title: article.title,
    url: article.link,
    media: article.source,
    time: formatKst(article.publishedAt),
    evidence: directMatches.length ? "회사/제품 직접 언급" : `${termSignal.label} 시장 신호 기반`
  }));
}

function sourceSummaryForCompanyAgenda(sources, termSignal) {
  if (!sources.length) return `${termSignal.label} 관련 원문 수집 대기`;
  const media = [...new Set(sources.map((source) => source.media))].slice(0, 2).join(", ");
  const directCount = sources.filter((source) => source.evidence === "회사/제품 직접 언급").length;
  const basis = directCount ? "직접 근거" : "시장 신호";
  return `${media} · ${basis} ${sources.length}건`;
}

function takeawayForCompanyAgenda(company, agenda, termId) {
  const guide = {
    agent: "우리 서비스에서 조회가 실행으로 바뀌는 접점을 찾고, 승인/로그/롤백 요구사항을 먼저 점검하세요.",
    mcp: "연동 후보 데이터와 업무 시스템을 우선순위화하고, 커넥터·권한 범위 전략을 점검하세요.",
    "ai-code": "코드 생성량보다 테스트 통과율, 리뷰 품질, 배포 실패 감소 같은 운영 지표로 비교하세요.",
    evalops: "품질 평가를 출시 전 QA가 아니라 운영 중 회귀 감지와 감사 로그 체계로 설계하세요.",
    "on-device": "지연시간이나 개인정보가 민감한 AI 기능을 로컬 처리 후보로 분리해 보세요.",
    sovereign: "국내 데이터 보관, 공공 조달, 산업별 특화 모델 요구가 기회인지 리스크인지 나눠 보세요."
  };
  return agenda.takeaway || guide[termId] || `${company.name}의 ${agenda.label} 움직임이 제품, 파트너십, 리스크에 주는 영향을 점검하세요.`;
}

function whyHotForTerm(term, matches, sourceCount, mentions) {
  const sources = [...new Set(matches.slice(0, 5).map((match) => match.article.source))];
  if (!matches.length) {
    return `${term.label} 관련 키워드가 상시 추적 대상에 올라와 있어 기본 레이더에 유지됩니다.`;
  }
  return `${sources.slice(0, 3).join(", ")} 등 ${sourceCount}개 소스에서 ${matches.length}개 기사 신호가 잡혔고, 키워드 가중 언급이 ${mentions}회로 묶였습니다.`;
}

function hotnessForTerm({ term, matches, sourceCount, mentions, relatedCompanies, sourceLinks }) {
  const sourceNames = [...new Set(matches.slice(0, 6).map((match) => match.article.source))];
  const recentHours = matches.length
    ? Math.max(1, Math.round((Date.now() - Math.max(...matches.map((match) => match.article.publishedAt.getTime()))) / 36e5))
    : null;

  return {
    formula: "소스 다양성 + 기사 신호 수 + 키워드 언급 밀도 + 기업 연결성을 함께 반영",
    reasons: [
      {
        label: "매체 분산",
        value: `${sourceCount}개`,
        detail: sourceNames.length
          ? `${sourceNames.slice(0, 3).join(", ")} 등 서로 다른 매체에서 같은 의제가 반복 감지됐습니다.`
          : "기본 추적 소스에서 상시 모니터링 중인 의제입니다."
      },
      {
        label: "기사 신호",
        value: `${Math.max(matches.length, sourceLinks.length)}건`,
        detail: "최근 24시간 수집분 중 제목과 요약이 해당 의제와 직접 맞물린 기사입니다."
      },
      {
        label: "언급 밀도",
        value: `${mentions}회`,
        detail: `${term.label} 및 유사 표현이 제목, 요약, 출처 신호에서 가중치 있게 반복됐습니다.`
      },
      {
        label: "기업 연결",
        value: `${relatedCompanies.length}곳`,
        detail: `${relatedCompanies.slice(0, 4).join(", ")}의 제품, 인프라, 정책 움직임과 연결됩니다.`
      },
      {
        label: "최신성",
        value: recentHours ? `${recentHours}h` : "상시",
        detail: recentHours ? `가장 최근 관련 신호가 약 ${recentHours}시간 전 수집됐습니다.` : "최신 기사 수집 전에도 추적해야 하는 상시 레이더 의제입니다."
      }
    ]
  };
}

function buildHotAgendas(scoredTerms, generatedAt) {
  const selected = scoredTerms.filter((term) => term.score > 0).slice(0, 5);
  const terms = selected.length >= 3 ? selected : agendaTerms.slice(0, 5).map((term, index) => ({
    ...term,
    score: 20 - index * 2,
    sourceCount: 3,
    matches: []
  }));

  return terms.map((term, index) => {
    const topSources = [...new Set(term.matches.slice(0, 6).map((match) => match.article.source))].slice(0, 3);
    const mentions = Math.max(18, term.score * 6 + term.sourceCount * 3);
    const sourceCount = Math.max(term.sourceCount, topSources.length || 3);
    const sourceLinks = sourcesForTerm(term, term.matches);
    const score = Math.min(100, Math.max(58, Math.round(62 + term.score * 3 + sourceCount * 2 - index * 2)));
    const reason = whyHotForTerm(term, term.matches, sourceCount, mentions);
    const keywords = hashtagsForTerm(term, term.matches);
    const relatedCompanies = relatedCompaniesForTerm(term, term.matches);
    const hotness = hotnessForTerm({
      term,
      matches: term.matches,
      sourceCount,
      mentions,
      relatedCompanies,
      sourceLinks
    });
    return {
      rank: index + 1,
      id: term.id,
      collectedAt: `${formatKst(generatedAt)} KST`,
      title: term.title,
      score,
      summary: term.summary,
      mentions,
      sources: sourceLinks,
      sourceCount,
      momentum: `+${Math.min(48, 12 + index * 3 + term.sourceCount * 4)}%`,
      metric: `${sourceCount}개 매체 보도`,
      reason,
      whyHot: reason,
      hotness,
      keywords,
      hashtags: keywords,
      related_companies: relatedCompanies,
      signals: topSources.length
        ? `${topSources.join(", ")} 중심 ${term.matches.length}개 신호`
        : `${term.label} 관련 기본 추적 신호`,
      articles: term.matches.slice(0, 4).map(({ article }) => ({
        title: article.title,
        source: article.source,
        url: article.link,
        time: formatKst(article.publishedAt)
      })),
      brief: term.brief
    };
  });
}

function buildCompanies(scoredTerms, generatedAt) {
  const scoreMap = new Map(scoredTerms.map((term) => [term.id, term.score]));
  const signalMap = new Map(scoredTerms.map((term) => [term.id, term]));
  const labelMap = new Map(agendaTerms.map((term) => [term.id, term]));

  return companies.map((company) => {
    const ranked = company.agendas
      .map((agenda, index) => {
        const termId = agenda.term;
        const term = labelMap.get(termId);
        const termSignal = signalMap.get(termId) || { ...term, matches: [], score: 0, sourceCount: 0 };
        const rawScore = termSignal.matches?.length ? scoreMap.get(termId) : 1;
        const evidenceSources = sourcesForCompanyAgenda(company, agenda, termSignal);
        return {
          label: agenda.label,
          weight: Math.min(98, Math.max(44, rawScore * 7 + 40 - index * 5)),
          color: term.color,
          description: agenda.description,
          heat: agenda.heat || [agenda.label, ...term.aliases.slice(0, 3)],
          sources: evidenceSources,
          sourceSummary: sourceSummaryForCompanyAgenda(evidenceSources, term),
          takeaway: takeawayForCompanyAgenda(company, agenda, termId),
          termId,
          term
        };
      })
      .sort((a, b) => b.weight - a.weight);

    return {
      id: company.id,
      name: company.name,
      sector: company.sector,
      color: company.color,
      short: company.short,
      focus: company.focus,
      updatedAt: `${formatKst(generatedAt)} KST`,
      keywords: ranked.slice(0, 5).map(({ label, weight, color, description, termId, sources, sourceSummary, takeaway }) => ({
        label,
        weight,
        color,
        description,
        termId,
        sources,
        sourceSummary,
        takeaway
      })),
      stack: ranked.slice(0, 3).map(({ label, description, weight, termId, sources, sourceSummary, takeaway }) => ({
        title: label,
        body: description,
        score: String(Math.round(weight)),
        date: formatKst(generatedAt),
        termId,
        sources,
        sourceSummary,
        takeaway
      })),
      heat: ranked.flatMap(({ heat }) => heat).slice(0, 12)
    };
  });
}

function buildKeywordData(scoredTerms, generatedAt) {
  return scoredTerms.slice(0, 6).map((term, index) => {
    const score = Math.min(98, Math.max(52, term.score * 7 + 50 - index * 2));
    const timeline = term.matches.slice(0, 4).map(({ article }) => ({
      time: formatKst(article.publishedAt),
      title: article.title,
      type: article.source,
      source: article.source,
      url: article.link
    }));

    while (timeline.length < 4) {
      timeline.push({
        time: formatKst(new Date(generatedAt.getTime() - timeline.length * 45 * 60 * 1000)),
        title: `${term.label} 관련 시장 신호 추적 업데이트`,
        type: "Radar",
        source: "Radar",
        url: ""
      });
    }

    return {
      id: term.id,
      label: term.label,
      score,
      aliases: term.aliases,
      keywords: hashtagsForTerm(term, term.matches),
      color: term.color,
      description: term.description,
      brief: term.brief,
      signals: `${term.matches.length || 3}개 기사 신호 · ${term.sourceCount || 2}개 소스`,
      timeline
    };
  });
}

function sourceSignalsFromArticles(articles) {
  const counts = new Map();
  for (const article of articles) counts.set(article.source, (counts.get(article.source) || 0) + 1);
  const ranked = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3);
  const max = ranked[0]?.[1] || 1;
  return ranked.map(([name, count]) => [name, widthPercent(count, max)]);
}

function buildData(articles, rawCount) {
  const generatedAt = new Date();
  const start = new Date(generatedAt.getTime() - 24 * 60 * 60 * 1000);
  const nextUpdate = nextKstMorning(generatedAt);
  const recent = articles.filter((article) => article.publishedAt >= start);
  const usableArticles = recent.length >= 12 ? recent : articles.slice(0, 80);
  const scoredTerms = scoreTerms(usableArticles);
  const hotAgendas = buildHotAgendas(scoredTerms, generatedAt);

  return {
    metadata: {
      snapshotDate: formatKstKey(generatedAt),
      generatedAt: `${formatKst(generatedAt)} KST`,
      baseDate: formatKstDate(generatedAt),
      windowLabel: `${formatKst(start)} - ${formatKst(generatedAt)} KST`,
      nextUpdate: `${formatKst(nextUpdate)} KST`
    },
    metrics: {
      articles: usableArticles.length,
      blogs: new Set(usableArticles.map((article) => article.source)).size,
      dedupeRate: `${Math.round((1 - usableArticles.length / Math.max(rawCount, usableArticles.length, 1)) * 100)}%`,
      newAgendas: `+${hotAgendas.length}`
    },
    sourceSignals: sourceSignalsFromArticles(usableArticles),
    monitoredSources: sources.map(({ name, region, kind, url, feed }) => ({ name, region, kind, url, feed })),
    collectionQueue: [
      [`${formatKst(nextUpdate)}`, "Domestic and global AI source sweep"],
      [`${formatKst(new Date(nextUpdate.getTime() + 15 * 60 * 1000))}`, "Agenda clustering and company signal scoring"],
      [`${formatKst(new Date(nextUpdate.getTime() + 30 * 60 * 1000))}`, "Dashboard data publish"]
    ],
    impactNotes: scoredTerms.slice(0, 3).map((term) => [
      term.label,
      term.brief.implication,
      term.color
    ]),
    hotAgendas,
    companies: buildCompanies(scoredTerms, generatedAt),
    keywordData: buildKeywordData(scoredTerms, generatedAt)
  };
}

async function existingData() {
  try {
    const source = await readFile(jsOutputPath, "utf8");
    const match = source.match(/window\.TECH_AGENDA_DATA\s*=\s*([\s\S]*?);\s*$/);
    return match ? JSON.parse(match[1]) : null;
  } catch {
    return null;
  }
}

function compactSnapshot(data) {
  return {
    date: data.metadata?.snapshotDate || "",
    metadata: data.metadata,
    metrics: data.metrics,
    sourceSignals: data.sourceSignals,
    hotAgendas: data.hotAgendas,
    companies: data.companies,
    keywordData: data.keywordData
  };
}

async function writeSnapshotAndLoadRecent(latestData, limit = 3) {
  await mkdir(historyDir, { recursive: true });
  const snapshotDate = latestData.metadata.snapshotDate;
  const snapshotPath = resolve(historyDir, `${snapshotDate}.json`);
  await writeFile(snapshotPath, `${JSON.stringify(latestData, null, 2)}\n`);

  const files = (await readdir(historyDir))
    .filter((file) => /^\d{4}-\d{2}-\d{2}\.json$/.test(file))
    .sort()
    .reverse()
    .slice(0, limit);

  const snapshots = [];
  for (const file of files) {
    try {
      const snapshot = JSON.parse(await readFile(resolve(historyDir, file), "utf8"));
      snapshots.push(compactSnapshot(snapshot));
    } catch (error) {
      console.warn(`[warn] Could not read history/${file}: ${error.message}`);
    }
  }
  return snapshots;
}

async function main() {
  const rawItems = (await Promise.all(sources.map(fetchSource))).flat();
  const articles = uniqByTitle(rawItems).sort((a, b) => b.publishedAt - a.publishedAt);

  if (!articles.length) {
    const previous = await existingData();
    if (previous) {
      console.warn("[warn] No fresh feed items. Keeping existing agenda-data.js.");
      return;
    }
    throw new Error("No feed items could be fetched, and no existing data file was found.");
  }

  const latestData = buildData(articles, rawItems.length);
  const days = await writeSnapshotAndLoadRecent(latestData, 3);
  const data = {
    ...latestData,
    days
  };
  const json = JSON.stringify(data, null, 2);
  await writeFile(jsOutputPath, `window.TECH_AGENDA_DATA = ${json};\n`);
  await writeFile(jsonOutputPath, `${json}\n`);
  console.log(
    `[ok] Updated agenda data with ${data.metrics.articles} articles from ${data.metrics.blogs} sources. Main file keeps ${days.length} day snapshots.`
  );
}

main().catch((error) => {
  console.error(`[error] ${error.message}`);
  process.exitCode = 1;
});
